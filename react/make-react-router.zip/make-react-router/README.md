## history

3种不同的方法创建 history 对象
1. createBrowserHistory h5 里面的 history api
2. createMemoryHistory non-DOM 的环境里面使用 react-native
3. createHashHistory 以前的浏览器



## h5 history api
window.history 的方法和属性
methods:
```js
back() forward() go()
```
property:
```js
length
```

