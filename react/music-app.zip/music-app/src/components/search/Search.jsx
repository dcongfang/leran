import React, { Component } from 'react';
class Search extends Component {
  state = {  }
  render() { 
    return ( 
      <div>
        search
      </div>
     );
  }
}
 
export default Search;