// 显示或隐藏 播放页面的
export const SHOW_PLAYER = "SHOW_PLAYER";
// 修改当前歌曲的
export const CHANGE_SONG = "CHANGE_SONG";